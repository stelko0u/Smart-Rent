import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { UserRepository } from '@/lib/repository/UserRepository';
import { PasswordResetTokenRepository } from '@/lib/repository/PasswordResetTokenRepository';

type ReqBody = {
  email?: string;
  token?: string;
  password?: string;
};

function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as ReqBody;

    const email =
      typeof body.email === 'string' ? normalizeEmail(body.email) : '';
    const rawToken = typeof body.token === 'string' ? body.token.trim() : '';
    const password = typeof body.password === 'string' ? body.password : '';

    if (!email || !rawToken || !password) {
      return NextResponse.json(
        { error: 'Email, token and password are required.' },
        { status: 400 },
      );
    }

    const tokenHash = crypto
      .createHash('sha256')
      .update(rawToken)
      .digest('hex');

    const resetToken = await PasswordResetTokenRepository.findByEmailAndToken(
      email,
      tokenHash,
    );

    if (!resetToken) {
      return NextResponse.json(
        { error: 'Invalid or expired token.' },
        { status: 400 },
      );
    }

    if (new Date(resetToken.expiresAt).getTime() < Date.now()) {
      await PasswordResetTokenRepository.deleteByEmail(email);

      return NextResponse.json(
        { error: 'Invalid or expired token.' },
        { status: 400 },
      );
    }

    const user = await UserRepository.findByEmail(email);

    if (!user) {
      return NextResponse.json({ error: 'User not found.' }, { status: 404 });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await UserRepository.update(user.id, {
      password: hashedPassword,
      mustChangePassword: false,
    });

    await PasswordResetTokenRepository.deleteByEmail(email);

    return NextResponse.json({
      ok: true,
      message: 'Password updated successfully.',
    });
  } catch (error) {
    console.error('POST /api/auth/reset-password error:', error);

    return NextResponse.json(
      { error: 'Internal server error.' },
      { status: 500 },
    );
  }
}
